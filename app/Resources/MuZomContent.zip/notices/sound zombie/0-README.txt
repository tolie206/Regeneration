This mod adds new sounds for the Simple Zombies
script created by sollaholla. 

WARNING:
These sounds were found on Epidemic Sounds!
https://www.epidemicsound.com/sound-effects/

Yes I do have a license to use these sounds! The
license is $12 a month or about $200/300 a year.
If you do not have a license, I am not responsible
for what happens to your channel. I recommend
downloading this for your own personal use. 


Installation:

Ensure you have OpenIV for this!
https://openiv.com/


Path:
mods -> x64 -> audio -> sfx -> SMISC

Drage the provided "waveload-pain-male" 
and "waveload-pain-female" OAC files here!
Ensure "Edit Mode" is on!


Enjoy!!


